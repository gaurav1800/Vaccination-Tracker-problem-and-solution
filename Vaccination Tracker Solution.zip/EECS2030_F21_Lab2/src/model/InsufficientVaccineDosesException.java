package model;

public class InsufficientVaccineDosesException extends RuntimeException {
	
	public InsufficientVaccineDosesException() {
		super();

	}
	
	
}


package model;

public class VaccineDistribution {
	
	private String finalString;
	
	private Vaccine vaccine;
	
	private int nod; // number of doses
	
	
	
	public VaccineDistribution() {
		// do nothing;
	}
	
	public VaccineDistribution(Vaccine vaccine, int nod) {
		this.vaccine = vaccine;
		this.nod = nod;
		
		this.finalString = this.nod + " doses of " + vaccine.getCodeName() + " by " + vaccine.getManufacturer();
		
	}
	
	public Vaccine getVaccine() {
		return this.vaccine;
	}
	
	public String toString() {
		return this.finalString;
	}
	
	public void setDose(int nod) {
		this.nod = this.nod + nod;
	}
	
	public int getDose() {
		return nod;
	}
	
	public String getVaccineCode() {
		return vaccine.getCodeName();
	}
	
	public String getVaccineManufacturer() {
		return vaccine.getManufacturer();
	}
	
}

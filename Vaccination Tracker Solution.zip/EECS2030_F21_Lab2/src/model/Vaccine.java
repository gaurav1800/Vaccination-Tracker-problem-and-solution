package model;


public class Vaccine {
	
	private String codeName;
	private String type;
	private String manufacturer;
	private String finalString;
	
	
	public Vaccine() {
		//do nothing;
	}
	
	public Vaccine(String codeName, String type, String manufacturer) {
		this.codeName = codeName;
		this.type = type;
		this.manufacturer = manufacturer;
		String s;
		
		if(isRecognizedVaccine(codeName)) {
			s = "Recognized vaccine: " + this.codeName + " (" + this.type +"; " + this.manufacturer + ")";
		}
		else {
			s = "Unrecognized vaccine: " + this.codeName + " (" + this.type +"; " + this.manufacturer + ")";
		}
		this.finalString = s;
	}
	public boolean isRecognizedVaccine(String codeName) {
		return (codeName == "mRNA-1273" || 
				codeName == "BNT162b2" || 
				codeName == "Ad26.COV2.S" || 
				codeName == "AZD1222");
	}
	
	public String getCodeName() {
		return this.codeName;
	}
	
	public String getManufacturer() {
		return this.manufacturer;
	}
	
	public String getType() {
		return this.type;
	}
	
	public String toString() {
		return this.finalString;
	}
	

}

	
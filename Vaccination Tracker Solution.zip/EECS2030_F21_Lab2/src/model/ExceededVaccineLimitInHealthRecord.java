package model;

public class ExceededVaccineLimitInHealthRecord extends RuntimeException{
	
	public ExceededVaccineLimitInHealthRecord() {
		super();
		
	}
	
}

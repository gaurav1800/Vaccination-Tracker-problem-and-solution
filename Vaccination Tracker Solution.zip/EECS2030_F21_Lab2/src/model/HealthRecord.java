package model;

public class HealthRecord {
	
	private String name;
	private String site[];
	private String date[];
	
	private int vaccineLimit; 
	private int numberOfDosesReceived; 
	
	private boolean appointmentSucceeded;
	private boolean appointmentFailed;
	
	private Vaccine vaccineInfo[];
	
	
	public HealthRecord() {
		//do nothing;
	}
	
	public HealthRecord(String name, int vaccineLimit) {
		this.name = name;
		this.vaccineLimit = vaccineLimit;
		
		
		site = new String[vaccineLimit];
		date = new String[vaccineLimit];
		
		vaccineInfo = new Vaccine[vaccineLimit];
		

		
		
	}
	
	
	
	public String getVaccinationReceipt() {
		String s;
		
		if(this.numberOfDosesReceived == 0) {
			s = this.name + " has not yet received any doses.";
		}
		else {
			s = "Number of doses "+ this.name + " has received: "+ this.numberOfDosesReceived + " ["; 
			for(int i = 0; i < this.numberOfDosesReceived; i++) {
				if( i != 0) {
					s += "; ";
				}
				s += "Recognized vaccine: ";
				s += vaccineInfo[i].getCodeName() + " ";
				s += "(" + vaccineInfo[i].getType() + "; " + vaccineInfo[i].getManufacturer() + ")";
				s += " in " + site[i] + " on " + date[i];
			}
			s += "]";

		}
		
		return s;
		}
	
	public void setSite(String site) {
		this.site[numberOfDosesReceived] = site;
	}
	
	public void setAppointmentSucceeded () {
		appointmentSucceeded = true; 
	}
	
	public void setAppointmentFailed () {
		appointmentFailed = true; 
	}
	

	public String getAppointmentStatus() {
		String s;
		
		if (appointmentSucceeded) {
			s = "Last vaccination appointment for " + this.name + " with " + this.site[numberOfDosesReceived] + " succeeded";
		}
		else if (appointmentFailed){
			s = "Last vaccination appointment for " + this.name + " with " + this.site[numberOfDosesReceived] + " failed"; 
		}
		else {
			s = "No vaccination appointment for " + this.name + " yet";
		}
		return s;
	}
	
	public int getVaccineLimit() {
		return vaccineLimit;
	}
	
	public int getNumberOfDosesReceived() {
		return numberOfDosesReceived;
	}
	
	public void addRecord(Vaccine v, String site, String date) {
		vaccineInfo[numberOfDosesReceived] = v;
		this.site[numberOfDosesReceived] = site;
		this.date[numberOfDosesReceived] = date;
		
		numberOfDosesReceived++;
	}
	
	
	
}

package model;

public class TooMuchDistributionException extends RuntimeException {

	public TooMuchDistributionException() {
		super();
	}
}

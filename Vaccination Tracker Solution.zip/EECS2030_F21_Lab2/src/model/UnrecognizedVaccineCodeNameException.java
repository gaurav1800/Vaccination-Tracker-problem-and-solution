package model;

public class UnrecognizedVaccineCodeNameException extends RuntimeException {

	public UnrecognizedVaccineCodeNameException() {
		super();
	}
}

package model;


public class VaccinationSite {
	
	private String siteName;
	private String finalString;
	
	private int maxDoses;
	private int totalSupply;
	private int appointmentCount;
	private final int maxAppointments = 200;
	
	
	private VaccineDistribution vaccineTracker [] = new VaccineDistribution[4];
	private int trackerCounter = 0;
	
	private HealthRecord appointment[];
	
	
	
	
	public VaccinationSite() {
		// do nothing;

	}
	
	public VaccinationSite(String siteName, int maxDoses) {
		this.siteName = siteName;
		this.maxDoses = maxDoses;
		
		vaccineTracker = new VaccineDistribution[4];
		
		appointment = new HealthRecord[maxAppointments];
		
		String s = this.siteName + " has " + this.totalSupply + " available doses: <>";
		this.finalString = s;
		
	}
	
	
	public int getNumberOfAvailableDoses() {
		return this.totalSupply;
	}
	
	
	public int getNumberOfAvailableDoses(String codeName) {
		for(int x = 0; x < trackerCounter; x++) {
			if(vaccineTracker[x].getVaccineCode() == codeName) {
				return vaccineTracker[x].getDose();
			}
		}
		return 0;
	}
	
	public VaccineDistribution getVaccineDistribution(Vaccine vaccine) {
		for(int x = 0; x < trackerCounter; x++) {
			String codeName = vaccine.getCodeName();
			if(vaccineTracker[x].getVaccineCode() == codeName) {
				return vaccineTracker[x];
			}
		}

		return null;
	}
	
	public void addDistribution(Vaccine v, int doses) {
		//Checking if vaccine is recognized
		if(!v.isRecognizedVaccine(v.getCodeName())) {
			throw new UnrecognizedVaccineCodeNameException();
		}
		
		//Checking if supply is more than the site limit for vaccines
		if(maxDoses < (totalSupply + doses)) {
			throw new TooMuchDistributionException();
		} 
		
		
		
		VaccineDistribution vaccineDistribution = getVaccineDistribution(v);
		
		if(vaccineDistribution == null) {
			vaccineTracker[trackerCounter] = new VaccineDistribution(v, doses);
			trackerCounter++;
		} 
		else {
			vaccineDistribution.setDose(doses);
		}
		
		totalSupply += doses;
		this.finalString = this.siteName + " has " + this.totalSupply + " available doses: <" + trackVaccineDoses() + ">";
		
	}
	
	public String trackVaccineDoses() {
		String s = "";
		for(int v = 0; v < trackerCounter; v++) {
			if (s != "") {
				s += ", ";
			}
			s += vaccineTracker[v].getDose() + " doses of " +  vaccineTracker[v].getVaccineManufacturer();
		}
		return s;
	}
	
	
	public void bookAppointment(HealthRecord name) {
		
		if(name.getVaccineLimit() == name.getNumberOfDosesReceived()) {
			throw new ExceededVaccineLimitInHealthRecord();
		}
		
		if( (appointmentCount < totalSupply) && (appointmentCount < maxAppointments) ) {
			appointment[appointmentCount] = name;
			appointmentCount++;
			name.setAppointmentSucceeded();
			name.setSite(this.siteName);
		}
		else {
			name.setAppointmentFailed();
			name.setSite(this.siteName);
			
			throw new InsufficientVaccineDosesException();
			
		}
	}
	
	
	public Vaccine getVaccineDose() {
		for( VaccineDistribution v: vaccineTracker) {
			if(v.getDose() > 0) {
				v.setDose(-1);
				return v.getVaccine();
			}
		}
		return null;
	}
	
	
	public void administer(String date) {
		for (int i = 0; i < appointmentCount; i++) {
			appointment[i].addRecord(getVaccineDose(),siteName, date);
		}
		
		totalSupply -= appointmentCount;
		appointmentCount = 0;
		this.finalString = this.siteName + " has " + this.totalSupply + " available doses: ";
		this.finalString += "<" + trackVaccineDoses() + ">";
	}
	
	
	public String toString() {
		return this.finalString;
	}
	
}
